# Packages
library(deSolve)
library(fda)
library(splines2)
library(pCODE)

# Exercice : Système Lotka–Volterra
# dx/dt = alpha*x - beta*x*y
# dy/dt = delta*beta*x*y - gamma*y

lv_deriv <- function(t, state, pars) {
  with(as.list(c(state, pars)), {
    dx <- alpha * x - beta * x * y
    dy <- delta * beta * x * y - gamma * y
    list(c(dx, dy))
  })
}

# Paramètres vrais
pars.true <- c(alpha = 1, beta = 0.2, delta = 0.5, gamma = 0.2)

# Donnée initiale
init <- c(x = 1, y = 2)

# Temps
times <- seq(0, 100, by = 1)
nobs  <- length(times)

# Résolution numérique
lv_true <- ode(y = init, times = times, func = lv_deriv, parms = pars.true)
x_true <- lv_true[, "x"]
y_true <- lv_true[, "y"]

# Génération des données bruitées
set.seed(123)
scale <- 0.5
x_obs <- x_true + scale * rnorm(nobs)
y_obs <- y_true + scale * rnorm(nobs)

# Tracé des solutions avec bruit
par(mfrow = c(1, 2))

# Proies
plot(times, x_true, type = "l", lwd = 2, xlab = "t", ylab = "x(t)",
     main = "Proies : vrai vs bruité")
points(times, x_obs, pch = 16, cex = 0.6, col = "red")
segments(times, x_obs, times, x_true, col = "gray")
legend("topright", legend = c("x vrai", "x bruité"),
       col = c("black", "red"), lty = c(1, NA), pch = c(NA, 16), bty = "n")

# Prédateurs
plot(times, y_true, type = "l", lwd = 2, xlab = "t", ylab = "y(t)",
     main = "Prédateurs : vrai vs bruité")
points(times, y_obs, pch = 16, cex = 0.6, col = "red")
segments(times, y_obs, times, y_true, col = "gray")
legend("topright", legend = c("y vrai", "y bruité"),
       col = c("black", "red"), lty = c(1, NA), pch = c(NA, 16), bty = "n")

# Moindres carrés pour estimer les paramètres
RSS <- function(parameters) {
  names(parameters) <- c("alpha", "beta", "delta", "gamma")
  out <- ode(y = init, times = times, func = lv_deriv, parms = parameters)
  fit_x <- out[, "x"]
  fit_y <- out[, "y"]
  sum((x_obs - fit_x)^2 + (y_obs - fit_y)^2)
}

# Optimisation
Opt <- optim(
  par    = c(alpha = 0.8, beta = 0.1, delta = 0.3, gamma = 0.1),
  fn     = RSS,
  method = "L-BFGS-B",
  lower  = c(0, 0, 0, 0)
)

pars.opt <- setNames(Opt$par, c("alpha", "beta", "delta", "gamma"))

# Affichage des paramètres
pars.true
pars.opt
