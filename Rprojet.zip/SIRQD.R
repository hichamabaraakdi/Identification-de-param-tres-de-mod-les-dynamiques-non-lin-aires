# ----------------------
# Packages
# ----------------------
library(deSolve)
library(neuralnet)

# Modèle SIRDQ
sir_dq <- function(t, state, parms) {
  with(as.list(c(state, parms)), {
    dS <- -beta * S * I
    dI <- beta * S * I - gamma * I - f * I - d * I
    dR <- gamma * I
    dD <- d * I
    dQ <- f * I
    list(c(dS, dI, dR, dD, dQ))
  })
}

# Paramètres vrais et conditions initiales
params_true <- c(beta = 0.3, gamma = 0.1, f = 0.05, d = 0.0113)
state0 <- c(S = 990, I = 10, R = 0, D = 0, Q = 0)
times <- seq(0, 50, by = 1)

# Simulation et bruit
set.seed(123)
sim <- ode(y = state0, times = times, func = sir_dq, parms = params_true)
sim_df <- as.data.frame(sim)

# Ajouter bruit
scale <- 5
sim_noisy <- sim_df
sim_noisy[, 2:6] <- sim_noisy[, 2:6] + scale*rnorm(length(times)*5)

# Préparer les données pour neuralnet
dX <- diff(as.matrix(sim_noisy[, 2:6])) / diff(times)  # dS, dI, dR, dD, dQ
X <- sim_noisy[-nrow(sim_noisy), 2:6]                 # S, I, R, D, Q

# Normalisation Min-Max des entrées uniquement
normalize <- function(x) {(x - min(x)) / (max(x) - min(x))}
X_norm <- as.data.frame(apply(X, 2, normalize))
colnames(X_norm) <- c("S","I","R","D","Q")

# Sorties brutes
dX_df <- as.data.frame(dX)
colnames(dX_df) <- c("dS","dI","dR","dD","dQ")

# Combinaison pour neuralnet
data_nn <- cbind(dX_df, X_norm)

# Entrainement
fmla <- as.formula("dS + dI + dR + dD + dQ ~ S + I + R + D + Q")
nn_model <- neuralnet(
  fmla,
  data = data_nn,
  hidden = c(10,10),  
  linear.output = TRUE,
  stepmax = 1e7,
  threshold = 0.01
)

plot(nn_model)


pred <- compute(nn_model, X_norm)
dX_pred <- as.data.frame(pred$net.result)
colnames(dX_pred) <- c("dS","dI","dR","dD","dQ")

#Estimations
S_vec <- X$S
I_vec <- X$I
dS_vec <- dX_pred$dS
dR_vec <- dX_pred$dR
dQ_vec <- dX_pred$dQ
dD_vec <- dX_pred$dD

beta_est  <- -mean(dS_vec / (S_vec * I_vec))
gamma_est <- mean(dR_vec / I_vec)
f_est     <- mean(dQ_vec / I_vec)
d_est     <- mean(dD_vec / I_vec)

cat("Paramètres vrais :\n")
print(params_true)
cat("\nParamètres estimés :\n")
cat("beta  =", beta_est, "\n")
cat("gamma =", gamma_est, "\n")
cat("f     =", f_est, "\n")
cat("d     =", d_est, "\n")

par(mfrow = c(2,3))

plot(times, sim_noisy$S, type="p", pch=16, col="red", main="S: observé vs prédit", xlab="t", ylab="S")
lines(times[-length(times)], dX_pred$dS * 1 + S_vec[1], col="blue")  

plot(times, sim_noisy$I, type="p", pch=16, col="red", main="I: observé vs prédit", xlab="t", ylab="I")
lines(times[-length(times)], I_vec[1] + cumsum(dX_pred$dI), col="blue")

plot(times, sim_noisy$R, type="p", pch=16, col="red", main="R: observé vs prédit", xlab="t", ylab="R")
lines(times[-length(times)], R_vec <- cumsum(dX_pred$dR) + X$R[1], col="blue")

plot(times, sim_noisy$D, type="p", pch=16, col="red", main="D: observé vs prédit", xlab="t", ylab="D")
lines(times[-length(times)], D_vec <- cumsum(dX_pred$dD) + X$D[1], col="blue")

plot(times, sim_noisy$Q, type="p", pch=16, col="red", main="Q: observé vs prédit", xlab="t", ylab="Q")
lines(times[-length(times)], Q_vec <- cumsum(dX_pred$dQ) + X$Q[1], col="blue")

