# Packages
library(deSolve)
library(fda)
library(splines2)
library(pCODE)

# Modèle SIR
sir_deriv <- function(t, state, pars) {
  with(as.list(c(state, pars)), {
    S <- N - I - R
    dI <- beta * S / N * I - gamma * I
    dR <- gamma * I
    list(c(dI, dR))
  })
}

# Paramètres vrais
N <- 1000
pars.true <- c(beta = 0.3, gamma = 0.1, N = N)

# Conditions initiales
init <- c(I = 10, R = 0)

# Temps
times <- seq(0, 100, by = 1)
nobs  <- length(times)

# Solution numérique
sir_true <- ode(y = init, times = times, func = sir_deriv, parms = pars.true)
I_true <- sir_true[, "I"]
R_true <- sir_true[, "R"]
S_true <- N - I_true - R_true

# Données bruitées
set.seed(123)
scale <- 5
S_obs <- S_true + scale * rnorm(nobs)
I_obs <- I_true + scale * rnorm(nobs)
R_obs <- R_true + scale * rnorm(nobs)

# Tracé des solutions avec bruit
par(mfrow = c(1, 3))

# Susceptibles
plot(times, S_true, type = "l", lwd = 2, xlab = "t", ylab = "S(t)", main = "Susceptibles")
points(times, S_obs, pch = 16, cex = 0.5, col = "red")
segments(times, S_obs, times, S_true, col = "gray")

# Infectés
plot(times, I_true, type = "l", lwd = 2, xlab = "t", ylab = "I(t)", main = "Infectés")
points(times, I_obs, pch = 16, cex = 0.5, col = "red")
segments(times, I_obs, times, I_true, col = "gray")

# Retirés
plot(times, R_true, type = "l", lwd = 2, xlab = "t", ylab = "R(t)", main = "Retirés")
points(times, R_obs, pch = 16, cex = 0.5, col = "red")
segments(times, R_obs, times, R_true, col = "gray")

# Moindres carrés pour estimer les paramètres
RSS <- function(parameters) {
  names(parameters) <- c("beta", "gamma")
  if (parameters["beta"] <= parameters["gamma"]) return(1e12)
  pars <- c(parameters, N = N)
  out <- ode(y = init, times = times, func = sir_deriv, parms = pars)
  I_fit <- out[, "I"]
  R_fit <- out[, "R"]
  S_fit <- N - I_fit - R_fit
  sum((S_obs - S_fit)^2 + (I_obs - I_fit)^2 + (R_obs - R_fit)^2)
}

# Optimisation
Opt <- optim(par = c(beta = 0.25, gamma = 0.08), fn = RSS, method = "L-BFGS-B",
             lower = c(0.05, 0.01), upper = c(1, 1))
pars.opt <- setNames(Opt$par, c("beta", "gamma"))

# Affichage des paramètres et R0
pars.true
pars.opt
R0_true <- as.numeric(pars.true["beta"] / pars.true["gamma"])
R0_est  <- as.numeric(pars.opt["beta"] / pars.opt["gamma"])
R0_true
R0_est
