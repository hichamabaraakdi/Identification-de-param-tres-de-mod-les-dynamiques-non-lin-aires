# Packages
library(deSolve)
library(fda)
library(splines2)
library(pCODE)

# Exercice : Modèle KPP-Fisher
# dx/dt = theta * x * (1 - x / n)

n <- 100

ode.model <- function(t, state, parms) {
  with(as.list(c(state, parms)), {
    dx <- theta * x * (1 - x / n)
    list(c(dx))
  })
}

# Paramètres du modèle
model.par <- c(theta = 0.1)

# Donnée initiale
state <- c(x = 0.1)

# Temps
times <- seq(0, 100, length.out = 101)

# Résolution numérique
mod <- ode(y = state, times = times, func = ode.model, parms = model.par)

# Génération des données bruitées
nobs  <- length(times)
scale <- 0.5
set.seed(123)
noise <- scale * rnorm(n = nobs, mean = 0, sd = 1)
observ <- mod[, "x"] + noise

# Représentation graphique de la solution
plot(times, mod[, "x"], type = "l", lwd = 2,
     xlab = "t", ylab = "x(t)",
     main = "Solution de l'équation KPP-Fisher")
points(times, observ, pch = 16, cex = 0.6, col = "blue")

# Moindres carrés pour estimer theta
RSS <- function(theta) {
  out <- ode(y = state, times = times, func = ode.model, parms = c(theta = theta))
  fit <- out[, "x"]
  sum((observ - fit)^2)
}

# Optimisation
Opt <- optim(par = 0.25, fn = RSS, method = "L-BFGS-B", lower = 0, upper = 1)
theta.opt <- Opt$par
theta.opt

# Tracé des écarts quadratiques (observations vs solution)
plot(times, observ, pch = 19, col = "red", xlab = "Temps", ylab = "x(t)", main = "Observations vs Modèle")
lines(times, mod[, "x"], col = "blue", type = "o")
segments(times, observ, times, mod[, "x"], col = "gray")
